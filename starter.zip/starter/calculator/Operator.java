package calculator;

abstract class Operator
{
  abstract void execute(State state);
}
